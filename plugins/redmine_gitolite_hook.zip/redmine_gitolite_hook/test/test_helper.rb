# Load the normal Rails helper from the Redmine host app
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')
